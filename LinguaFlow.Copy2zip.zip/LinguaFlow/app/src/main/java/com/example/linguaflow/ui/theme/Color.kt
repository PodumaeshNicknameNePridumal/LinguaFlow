package com.example.linguaflow.ui.theme

import androidx.compose.ui.graphics.Color

val PurpleDark = Color(0xFF9C27B0)
val Biruz = Color(0xFF07E0B4)
val BiruzDark = Color(0xFF009688)
val BiruzLight = Color(0xFF03DAC5)

