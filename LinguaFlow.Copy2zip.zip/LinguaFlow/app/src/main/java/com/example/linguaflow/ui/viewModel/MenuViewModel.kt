package com.example.linguaflow.ui.viewModel

import androidx.lifecycle.ViewModel

class MenuViewModel: ViewModel() {

}